import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Homepage
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Trilight Group | Luxury Real Estate Development</title>
        
        <!-- Modern Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
        <!-- Icons & Libraries -->
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
        
        <!-- Styles -->
        <link href="/static/styles.css" rel="stylesheet">
    </head>
    <body>
        <!-- Navigation -->
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <div class="logo-mark">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    <span class="logo-text">TRILIGHT GROUP</span>
                </div>
                
                <div class="nav-links" id="navLinks">
                    <a href="#home" class="nav-link active">Home</a>
                    <a href="#projects" class="nav-link">Projects</a>
                    <a href="#about" class="nav-link">About</a>
                    <a href="#contact" class="nav-link">Contact</a>
                </div>
                
                <div class="nav-actions">
                    <button class="btn-enquire">Enquire Now</button>
                    <button class="menu-toggle" id="menuToggle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section id="home" class="hero">
            <div class="hero-bg">
                <div class="hero-overlay"></div>
            </div>
            <div class="hero-content">
                <div class="hero-badge">LUXURY LIVING REDEFINED</div>
                <h1 class="hero-title">
                    THE ART OF
                    <span class="gradient-text">EXCEPTIONAL LIVING</span>
                </h1>
                <p class="hero-subtitle">
                    Crafting Hyderabad's most prestigious residential addresses with unparalleled quality and timeless design
                </p>
                <div class="hero-actions">
                    <button class="btn-primary">
                        <span>Explore Projects</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                    <button class="btn-secondary">
                        <i class="fas fa-play"></i>
                        <span>Watch Video</span>
                    </button>
                </div>
            </div>
            <div class="scroll-indicator">
                <div class="mouse"></div>
                <span>Scroll to discover</span>
            </div>
        </section>

        <!-- Stats Bar -->
        <section class="stats-bar">
            <div class="container-fluid">
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-number" data-target="15">0</div>
                        <div class="stat-label">Years of Excellence</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number" data-target="2500">0</div>
                        <div class="stat-label">Happy Families</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number" data-target="25">0</div>
                        <div class="stat-label">Landmark Projects</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number" data-target="5">0</div>
                        <div class="stat-label">Million Sq.Ft Delivered</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Brand Philosophy -->
        <section class="philosophy">
            <div class="container">
                <div class="section-header centered">
                    <span class="section-tag">OUR PHILOSOPHY</span>
                    <h2 class="section-title">The Art of The Detail</h2>
                    <p class="section-desc">
                        Every element is thoughtfully crafted, every space meticulously designed, 
                        creating residences that stand the test of time
                    </p>
                </div>
                
                <div class="pillars-grid">
                    <div class="pillar-card">
                        <div class="pillar-icon">
                            <i class="fas fa-gem"></i>
                        </div>
                        <h3>Signature Quality</h3>
                        <p>Premium materials and superior craftsmanship in every detail</p>
                    </div>
                    <div class="pillar-card">
                        <div class="pillar-icon">
                            <i class="fas fa-drafting-compass"></i>
                        </div>
                        <h3>Thoughtful Design</h3>
                        <p>Architectural excellence meets functional sophistication</p>
                    </div>
                    <div class="pillar-card">
                        <div class="pillar-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3>Trusted Legacy</h3>
                        <p>15 years of delivering exceptional residential experiences</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Featured Projects -->
        <section id="projects" class="projects">
            <div class="container">
                <div class="section-header">
                    <span class="section-tag">FEATURED DEVELOPMENTS</span>
                    <h2 class="section-title">Explore Our Luxury Properties</h2>
                </div>
                
                <div class="projects-carousel swiper">
                    <div class="swiper-wrapper">
                        <!-- Rise Project -->
                        <div class="swiper-slide">
                            <div class="project-card">
                                <div class="project-image">
                                    <div class="project-badge">FLAGSHIP PROJECT</div>
                                    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect fill='%231a1a2e' width='800' height='600'/%3E%3Ctext x='50%25' y='50%25' font-size='60' fill='%23d4af37' text-anchor='middle' dominant-baseline='middle' font-family='Inter'%3ERISE%3C/text%3E%3C/svg%3E" alt="Rise at Neopolis">
                                </div>
                                <div class="project-content">
                                    <div class="project-header">
                                        <h3 class="project-name">RISE</h3>
                                        <span class="project-location">
                                            <i class="fas fa-map-marker-alt"></i>
                                            Neopolis, Kokapet
                                        </span>
                                    </div>
                                    <p class="project-desc">
                                        9 premium towers featuring 1,080 luxury apartments with world-class amenities in Hyderabad's most prestigious address
                                    </p>
                                    <div class="project-amenities">
                                        <div class="amenity-tag">
                                            <i class="fas fa-building"></i>
                                            <span>2, 3, 4 BHK</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-swimming-pool"></i>
                                            <span>Infinity Pool</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-dumbbell"></i>
                                            <span>Fitness Center</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-tree"></i>
                                            <span>75% Green Space</span>
                                        </div>
                                    </div>
                                    <div class="project-footer">
                                        <div class="project-price">
                                            <span class="label">Starting from</span>
                                            <span class="price">₹1.2 Cr*</span>
                                        </div>
                                        <button class="btn-view-details">
                                            View Details
                                            <i class="fas fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Trisire Project -->
                        <div class="swiper-slide">
                            <div class="project-card">
                                <div class="project-image">
                                    <div class="project-badge ready">READY TO MOVE</div>
                                    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect fill='%231a1a2e' width='800' height='600'/%3E%3Ctext x='50%25' y='50%25' font-size='50' fill='%23d4af37' text-anchor='middle' dominant-baseline='middle' font-family='Inter'%3ETRISIRE%3C/text%3E%3C/svg%3E" alt="Trisire Villas">
                                </div>
                                <div class="project-content">
                                    <div class="project-header">
                                        <h3 class="project-name">TRISIRE</h3>
                                        <span class="project-location">
                                            <i class="fas fa-map-marker-alt"></i>
                                            Premium Villas
                                        </span>
                                    </div>
                                    <p class="project-desc">
                                        45 exclusive luxury villas with private gardens, offering an unparalleled lifestyle of privacy and sophistication
                                    </p>
                                    <div class="project-amenities">
                                        <div class="amenity-tag">
                                            <i class="fas fa-home"></i>
                                            <span>3, 4 BHK Villas</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-car"></i>
                                            <span>Private Parking</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-shield-alt"></i>
                                            <span>Gated Community</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-seedling"></i>
                                            <span>Private Gardens</span>
                                        </div>
                                    </div>
                                    <div class="project-footer">
                                        <div class="project-price">
                                            <span class="label">Starting from</span>
                                            <span class="price">₹2.5 Cr*</span>
                                        </div>
                                        <button class="btn-view-details">
                                            View Details
                                            <i class="fas fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Kompally Project -->
                        <div class="swiper-slide">
                            <div class="project-card">
                                <div class="project-image">
                                    <div class="project-badge upcoming">COMING SOON</div>
                                    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect fill='%231a1a2e' width='800' height='600'/%3E%3Ctext x='50%25' y='50%25' font-size='48' fill='%23d4af37' text-anchor='middle' dominant-baseline='middle' font-family='Inter'%3EKOMPALLY%3C/text%3E%3C/svg%3E" alt="Kompally Project">
                                </div>
                                <div class="project-content">
                                    <div class="project-header">
                                        <h3 class="project-name">KOMPALLY</h3>
                                        <span class="project-location">
                                            <i class="fas fa-map-marker-alt"></i>
                                            North Hyderabad
                                        </span>
                                    </div>
                                    <p class="project-desc">
                                        Our upcoming masterpiece in Kompally - redefining luxury living in North Hyderabad with smart homes and premium amenities
                                    </p>
                                    <div class="project-amenities">
                                        <div class="amenity-tag">
                                            <i class="fas fa-map-marker-alt"></i>
                                            <span>Prime Location</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-robot"></i>
                                            <span>Smart Homes</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-star"></i>
                                            <span>Premium Amenities</span>
                                        </div>
                                        <div class="amenity-tag">
                                            <i class="fas fa-leaf"></i>
                                            <span>Eco-Friendly</span>
                                        </div>
                                    </div>
                                    <div class="project-footer">
                                        <div class="project-price">
                                            <span class="label">Pre-launch</span>
                                            <span class="price">Register Now</span>
                                        </div>
                                        <button class="btn-view-details">
                                            Register Interest
                                            <i class="fas fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Navigation -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section id="about" class="about">
            <div class="container-fluid">
                <div class="about-grid">
                    <div class="about-content">
                        <span class="section-tag">ABOUT TRILIGHT GROUP</span>
                        <h2 class="section-title">Building Dreams, Creating Landmarks</h2>
                        <p class="about-text">
                            For over 15 years, Trilight Group has been synonymous with luxury, quality, and innovation in Hyderabad's real estate landscape. Our commitment to excellence has made us the preferred choice for discerning homebuyers.
                        </p>
                        <p class="about-text">
                            We don't just build homes; we create communities where families thrive, memories are made, and lifestyles are elevated. Every project reflects our unwavering dedication to superior craftsmanship and timeless design.
                        </p>
                        <div class="about-features">
                            <div class="feature-item">
                                <i class="fas fa-check-circle"></i>
                                <span>End-to-end project management</span>
                            </div>
                            <div class="feature-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Premium quality materials</span>
                            </div>
                            <div class="feature-item">
                                <i class="fas fa-check-circle"></i>
                                <span>On-time delivery commitment</span>
                            </div>
                            <div class="feature-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Customer-centric approach</span>
                            </div>
                        </div>
                        <button class="btn-primary mt-30">
                            <span>Learn More</span>
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                    <div class="about-image">
                        <div class="image-wrapper">
                            <div class="image-badge">
                                <i class="fas fa-award"></i>
                                <div>
                                    <strong>Award Winning</strong>
                                    <span>Developer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="contact">
            <div class="container">
                <div class="contact-grid">
                    <div class="contact-info">
                        <span class="section-tag">GET IN TOUCH</span>
                        <h2 class="section-title">Let's Build Your Dream Home</h2>
                        <p class="contact-desc">
                            Our team is here to help you find the perfect home. Reach out today and let's start your journey to luxury living.
                        </p>
                        
                        <div class="info-cards">
                            <div class="info-card">
                                <div class="info-icon">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="info-text">
                                    <h4>Call Us</h4>
                                    <p>+91 40 1234 5678</p>
                                    <p>Mon - Sat: 9 AM - 7 PM</p>
                                </div>
                            </div>
                            
                            <div class="info-card">
                                <div class="info-icon">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="info-text">
                                    <h4>Email Us</h4>
                                    <p>sales@trilightgroup.com</p>
                                    <p>info@trilightgroup.com</p>
                                </div>
                            </div>
                            
                            <div class="info-card">
                                <div class="info-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info-text">
                                    <h4>Visit Us</h4>
                                    <p>Financial District</p>
                                    <p>Hyderabad, Telangana</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-form-wrapper">
                        <form class="contact-form" id="contactForm">
                            <div class="form-group">
                                <input type="text" name="name" placeholder="Your Name" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Email Address" required>
                            </div>
                            <div class="form-group">
                                <input type="tel" name="phone" placeholder="Phone Number" required>
                            </div>
                            <div class="form-group">
                                <select name="project" required>
                                    <option value="">Select Project</option>
                                    <option value="rise">Rise - Neopolis, Kokapet</option>
                                    <option value="trisire">Trisire - Luxury Villas</option>
                                    <option value="kompally">Kompally - Coming Soon</option>
                                    <option value="general">General Inquiry</option>
                                </select>
                            </div>
                            <div class="form-group full">
                                <textarea name="message" rows="4" placeholder="Your Message" required></textarea>
                            </div>
                            <button type="submit" class="btn-primary full">
                                <span>Send Message</span>
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="footer">
            <div class="container">
                <div class="footer-main">
                    <div class="footer-col footer-brand">
                        <div class="footer-logo">
                            <div class="logo-mark">
                                <span class="star">★</span>
                                <span class="star">★</span>
                                <span class="star">★</span>
                            </div>
                            <span class="logo-text">TRILIGHT GROUP</span>
                        </div>
                        <p class="footer-desc">
                            Crafting Hyderabad's most prestigious residential addresses with unparalleled quality and timeless design.
                        </p>
                        <div class="social-links">
                            <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                            <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                            <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                    
                    <div class="footer-col">
                        <h4>Projects</h4>
                        <ul>
                            <li><a href="#rise">Rise at Neopolis</a></li>
                            <li><a href="#trisire">Trisire Villas</a></li>
                            <li><a href="#kompally">Kompally</a></li>
                            <li><a href="#ongoing">Ongoing Projects</a></li>
                            <li><a href="#completed">Completed Projects</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-col">
                        <h4>Company</h4>
                        <ul>
                            <li><a href="#about">About Us</a></li>
                            <li><a href="#careers">Careers</a></li>
                            <li><a href="#media">Media Center</a></li>
                            <li><a href="#awards">Awards</a></li>
                            <li><a href="#contact">Contact Us</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-col">
                        <h4>Resources</h4>
                        <ul>
                            <li><a href="#emi">EMI Calculator</a></li>
                            <li><a href="#brochures">Download Brochures</a></li>
                            <li><a href="#site-visit">Book Site Visit</a></li>
                            <li><a href="#blog">Blog</a></li>
                            <li><a href="#faq">FAQ</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-col">
                        <h4>Newsletter</h4>
                        <p class="newsletter-text">Stay updated with our latest projects and offers</p>
                        <form class="newsletter-form">
                            <input type="email" placeholder="Enter your email" required>
                            <button type="submit"><i class="fas fa-arrow-right"></i></button>
                        </form>
                    </div>
                </div>
                
                <div class="footer-bottom">
                    <div class="footer-legal">
                        <a href="#privacy">Privacy Policy</a>
                        <span>•</span>
                        <a href="#terms">Terms & Conditions</a>
                        <span>•</span>
                        <a href="#disclaimer">Disclaimer</a>
                    </div>
                    <p class="copyright">
                        © 2024 Trilight Group. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>

        <!-- Sticky CTA -->
        <div class="sticky-cta">
            <button class="btn-sticky">
                <i class="fas fa-phone"></i>
                <span>Call Now</span>
            </button>
            <button class="btn-sticky">
                <i class="fab fa-whatsapp"></i>
                <span>WhatsApp</span>
            </button>
        </div>

        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

export default app
